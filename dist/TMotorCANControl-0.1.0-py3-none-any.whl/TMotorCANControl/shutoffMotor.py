from TControl import TMotorManager

motor = TMotorManager(motor_ID=3)
motor.power_off()

